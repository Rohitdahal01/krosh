from flask import Flask, render_template, jsonify
from flask_mysqldb import MySQL
from flask_cors import CORS  # Import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Database configuration
app.config['MYSQL_HOST'] = '127.0.0.1'  
app.config['MYSQL_USER'] = 'root'  
app.config['MYSQL_PASSWORD'] = '1231'  
app.config['MYSQL_DB'] = 'game_database'

# Initialize MySQL
mysql = MySQL(app)

@app.route('/api/airports', methods=['GET'])
def get_airports():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, airport_name, latitude, longitude FROM airports")
    airports = cursor.fetchall()
    
    airport_data = [{"id": airport[0], "airport_name": airport[1], "latitude": airport[2], "longitude": airport[3]} for airport in airports]
    return jsonify(airport_data)

if __name__ == '__main__':
    app.run(debug=True)
