let currentDestinationIndex = 0; // Tracks the current airport
let destinations = []; // Empty array to hold airport names
let destinationsCoordinates = []; // Empty array to hold airport coordinates
const BASE_URL = "https://opentdb.com/api.php?amount=50&category=22&difficulty=medium&type=multiple"; // Open Trivia Database API URL

let currentQuestions = []; // Store fetched questions
let map;
let airplaneMarker = null;
let flightPath = null;
let animationInterval = null;

// Fetch airport data from Flask API
async function fetchAirportsData() {
    try {
        const response = await fetch("http://localhost:5000/api/airports"); // Flask API endpoint
        if (!response.ok) throw new Error("Failed to fetch airport data");

        const airports = await response.json();

        // Store the fetched data in the destinations array and coordinates array
        airports.forEach(airport => {
            destinations.push(airport.airport_name);
            destinationsCoordinates.push({
                name: airport.airport_name,
                lat: airport.latitude,
                lng: airport.longitude,
            });
        });

        console.log("Airports fetched:", destinations);
    } catch (error) {
        console.error("Error fetching airport data:", error);
        alert("Could not fetch airport data. Try again later.");
    }
}

// Initialize Google Map
function initMap() {
    const initialLocation = { lat: 0, lng: 0 }; // Initial map center
    map = new google.maps.Map(document.getElementById("map-container"), {
        zoom: 4,
        center: initialLocation,
    });

    // Create the airplane marker
    airplaneMarker = new google.maps.Marker({
        position: initialLocation,
        map: map,
        icon: {
            url: "question game/photos/WhatsApp Image 2024-12-15 at 18.09.55_ef08ee05.jpg", // Use local airplane image
            scaledSize: new google.maps.Size(40, 40), // Resize the icon
        },
        title: "Airplane",
    });
}

// Fetch Questions from Open Trivia Database
async function fetchQuestions() {
    try {
        const response = await fetch(BASE_URL);
        if (!response.ok) throw new Error("Failed to fetch questions");

        const data = await response.json();
        currentQuestions = data.results.map(q => ({
            question: q.question,
            correct_answer: q.correct_answer,
            incorrect_answers: q.incorrect_answers
        }));

        console.log("Questions fetched:", currentQuestions);
    } catch (error) {
        console.error("Error fetching questions:", error);
        alert("Could not fetch questions. Try again later.");
    }
}

// Load Question in Popup
function loadQuestionInPopup() {
    if (currentQuestions.length === 0) {
        alert("No questions available. Refresh to try again.");
        return;
    }

    const question = currentQuestions.pop();
    const answers = [...question.incorrect_answers, question.correct_answer];
    answers.sort(() => Math.random() - 0.5);

    let questionText = `Question for ${destinations[currentDestinationIndex]}: ${question.question}\n\n`;
    answers.forEach((answer, index) => {
        questionText += `${index + 1}. ${answer}\n`;
    });

    const playerAnswer = prompt(questionText + "\nEnter the number of your answer:");

    if (playerAnswer !== null) {
        checkAnswerPopup(answers[parseInt(playerAnswer) - 1], question.correct_answer);
    } else {
        alert("No answer selected. Try again.");
    }
}

// Check Answer for Popup
function checkAnswerPopup(playerAnswer, correctAnswer) {
    if (playerAnswer === correctAnswer) {
        alert("Correct! Moving to the next destination...");

        if (currentDestinationIndex < destinations.length - 1) {
            const nextIndex = currentDestinationIndex + 1;
            updateMap(nextIndex); // Update map and animate airplane
            currentDestinationIndex = nextIndex;
            setTimeout(loadQuestionInPopup, 4000); // Delay loading next question until animation ends
        } else {
            alert("Congratulations! You have landed on Panama safely!");

            // Show the "Next Game" button when the last destination is reached
            document.getElementById("next-game-button").style.display = "block";
        }
    } else {
        alert(`Wrong! The correct answer was: ${correctAnswer}. You are being redirected to the previous airport...`);

        // Go back to the previous airport
        if (currentDestinationIndex > 0) {
            const prevIndex = currentDestinationIndex - 1;
            updateMap(prevIndex); // Update map and animate airplane
            currentDestinationIndex = prevIndex;
            setTimeout(loadQuestionInPopup, 4000); // Delay loading next question until animation ends
        } else {
            alert("You are at the first airport. Try again!");
        }
    }
}

// Update Map and Animate Airplane
function updateMap(destinationIndex) {
    const currentDestination = destinationsCoordinates[currentDestinationIndex];
    const nextDestination = destinationsCoordinates[destinationIndex];

    // Update the current destination on the HTML page
    document.getElementById("current-destination").textContent = destinations[destinationIndex];

    // Draw a line between the current and next destinations
    if (flightPath) flightPath.setMap(null); // Remove the previous flight path
    flightPath = new google.maps.Polyline({
        path: [
            { lat: currentDestination.lat, lng: currentDestination.lng },
            { lat: nextDestination.lat, lng: nextDestination.lng },
        ],
        geodesic: true,
        strokeColor: "#FF0000",
        strokeOpacity: 1.0,
        strokeWeight: 2,
    });
    flightPath.setMap(map);

    // Start airplane animation
    animateAirplane(currentDestination, nextDestination);
}

// Animate the Airplane Marker
function animateAirplane(start, end) {
    if (animationInterval) clearInterval(animationInterval); // Clear any ongoing animation

    const steps = 200; // Number of animation steps
    let step = 0;

    const latStep = (end.lat - start.lat) / steps;
    const lngStep = (end.lng - start.lng) / steps;

    // Start animation
    animationInterval = setInterval(() => {
        if (step >= steps) {
            clearInterval(animationInterval);
            airplaneMarker.setPosition(end); // Ensure airplane ends exactly at the destination
            map.setCenter(end); // Keep the map centered on the airplane
            return;
        }

        const newLat = start.lat + latStep * step;
        const newLng = start.lng + lngStep * step;

        airplaneMarker.setPosition({ lat: newLat, lng: newLng });
        map.setCenter({ lat: newLat, lng: newLng }); // Optional: Keep map centered on the airplane

        step++;
    }, 20); // Update every 20ms
}

// Start Game
async function initializeGame() {
    await fetchAirportsData(); // Fetch airports data from Flask API
    await fetchQuestions(); // Fetch trivia questions from Open Trivia Database
    initMap(); // Initialize the Google Map

    document.getElementById("start-button").onclick = () => {
        document.getElementById("start-button").style.display = "none";
        handleTakeoffOrLanding();
    };
}

function handleTakeoffOrLanding() {
    document.getElementById("current-destination").textContent = destinations[currentDestinationIndex];
    loadQuestionInPopup();
}

document.addEventListener("DOMContentLoaded", initializeGame);
