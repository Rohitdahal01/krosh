// Canvas setup
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Game variables
const SCREEN_WIDTH = 800;
const SCREEN_HEIGHT = 600;
const PLAYER_HEALTH = 50;
const ENEMY_HEALTH = 100;
const BULLET_DAMAGE = 1;
const ENEMY_BULLET_DAMAGE = 2;

let keys = {};
let playerBullets = [];
let enemyBullets = [];
let running = false; // Game starts paused for intro message

// Player object
const player = {
  x: 100,
  y: SCREEN_HEIGHT / 2 - 25,
  width: 50,
  height: 50,
  health: PLAYER_HEALTH,
  speed: 5,
  image: new Image(),
  draw() {
    ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
  },
  move(dx, dy) {
    this.x += dx * this.speed;
    this.y += dy * this.speed;
    // Keep within bounds
    this.x = Math.max(0, Math.min(this.x, SCREEN_WIDTH - this.width));
    this.y = Math.max(0, Math.min(this.y, SCREEN_HEIGHT - this.height));
  },
  shoot() {
    if (playerBullets.length < 5) {
      playerBullets.push({ x: this.x + this.width, y: this.y + this.height / 2, width: 10, height: 5 });
    }
  },
};

// Enemy object
const enemy = {
  x: SCREEN_WIDTH - 170,
  y: SCREEN_HEIGHT / 2 - 35,
  width: 70,
  height: 70,
  health: ENEMY_HEALTH,
  speed: 2,
  image: new Image(),
  draw() {
    ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
  },
  move(targetY) {
    if (this.y < targetY) this.y += this.speed;
    else if (this.y > targetY) this.y -= this.speed;
  },
  shoot() {
    if (enemyBullets.length < 5 && Math.random() < 0.05) {
      enemyBullets.push({ x: this.x - 10, y: this.y + this.height / 2, width: 10, height: 5 });
    }
  },
};

// Load assets
player.image.src = 'image/player.png';
enemy.image.src = 'image/gunda.png';

// Draw health bar
function drawHealthBar(x, y, currentHealth, maxHealth, color) {
  ctx.fillStyle = 'red';
  ctx.fillRect(x, y, 100, 10); // Background
  ctx.fillStyle = color;
  ctx.fillRect(x, y, 100 * (currentHealth / maxHealth), 10); // Health
}

// Draw the intro message
function drawIntroMessage() {
  ctx.clearRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
  ctx.fillStyle = 'yellow';
  ctx.textAlign = 'center';
  ctx.font = '30px Arial';
  ctx.fillText('You have landed in Panama.', SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 50);
  ctx.fillText('Now defeat the enemy in order to win the treasure.', SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2);
  ctx.fillText('Press ENTER to begin the game!', SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 + 50);
}

// Update and draw bullets
function updateBullets(bullets, dx, target, damage) {
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].x += dx;
    if (
      bullets[i].x < 0 || 
      bullets[i].x > SCREEN_WIDTH || 
      (bullets[i].x < target.x + target.width &&
       bullets[i].x + bullets[i].width > target.x &&
       bullets[i].y < target.y + target.height &&
       bullets[i].y + bullets[i].height > target.y)
    ) {
      if (
        bullets[i].x < target.x + target.width &&
        bullets[i].x + bullets[i].width > target.x &&
        bullets[i].y < target.y + target.height &&
        bullets[i].y + bullets[i].height > target.y
      ) {
        target.health -= damage;
      }
      bullets.splice(i, 1); // Remove bullet
    }
  }
}

// Draw the end message on canvas
function drawEndMessage(message) {
  ctx.fillStyle = 'yellow';
  ctx.textAlign = 'center';
  ctx.font = '28.5px Arial';

  const lines = [];
  const maxLineWidth = SCREEN_WIDTH - 40; // Maximum width for each line
  let line = '';
  for (let i = 0; i < message.length; i++) {
    line += message[i];
    if (ctx.measureText(line).width > maxLineWidth) {
      lines.push(line.slice(0, -1)); // Add the current line to the array
      line = message[i]; // Start a new line with the current character
    }
  }
  if (line) lines.push(line); // Add the last line

  const totalHeight = lines.length * 40; // Line height is 40px
  let yPosition = SCREEN_HEIGHT / 2 - totalHeight / 2;
  for (let i = 0; i < lines.length; i++) {
    ctx.fillText(lines[i], SCREEN_WIDTH / 2, yPosition);
    yPosition += 40; // Move down for the next line
  }
}

// Main game loop
function gameLoop() {
  if (!running) {
    if (player.health <= 0) {
      drawEndMessage('Oh No! You have been defeated. You have to start from the beginning');
    } else if (enemy.health <= 0) {
      drawEndMessage('Congratulations!! You have defeated the enemy.');
    }
    return;
  }

  ctx.clearRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

  const dx = (keys['ArrowRight'] ? 1 : 0) - (keys['ArrowLeft'] ? 1 : 0);
  const dy = (keys['ArrowDown'] ? 1 : 0) - (keys['ArrowUp'] ? 1 : 0);
  player.move(dx, dy);

  enemy.move(player.y);
  enemy.shoot();

  updateBullets(playerBullets, 10, enemy, BULLET_DAMAGE);
  updateBullets(enemyBullets, -10, player, ENEMY_BULLET_DAMAGE);

  if (player.health <= 0 || enemy.health <= 0) {
    running = false;
  }

  player.draw();
  enemy.draw();

  ctx.fillStyle = 'yellow'; 
  playerBullets.forEach(b => ctx.fillRect(b.x, b.y, b.width, b.height));

  ctx.fillStyle = 'red'; 
  enemyBullets.forEach(b => ctx.fillRect(b.x, b.y, b.width, b.height));

  drawHealthBar(10, 10, player.health, PLAYER_HEALTH, 'green');
  drawHealthBar(SCREEN_WIDTH - 110, 10, enemy.health, ENEMY_HEALTH, 'green');

  requestAnimationFrame(gameLoop);
}

// Event listeners
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !running) {
    running = true; // Start the game
    gameLoop();
  } else if (running) {
    keys[e.key] = true;
    if (e.key === ' ') player.shoot();
  }
});
document.addEventListener('keyup', e => (keys[e.key] = false));

// Display intro message before the game starts
drawIntroMessage();
